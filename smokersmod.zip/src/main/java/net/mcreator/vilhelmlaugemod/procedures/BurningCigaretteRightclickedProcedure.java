package net.mcreator.vilhelmlaugemod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.vilhelmlaugemod.VilhelmlaugemodMod;

public class BurningCigaretteRightclickedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		VilhelmlaugemodMod.queueServerWork(2400, () -> {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("You feel an urge to smoke again..."), false);
		});
	}
}
