
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vilhelmlaugemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;

import net.mcreator.vilhelmlaugemod.item.TablogoItem;
import net.mcreator.vilhelmlaugemod.item.CigaretteItem;
import net.mcreator.vilhelmlaugemod.item.BurningCigaretteItem;
import net.mcreator.vilhelmlaugemod.VilhelmlaugemodMod;

public class VilhelmlaugemodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(VilhelmlaugemodMod.MODID);
	public static final DeferredItem<Item> CIGARETTE = REGISTRY.register("cigarette", CigaretteItem::new);
	public static final DeferredItem<Item> TOBAKKO = REGISTRY.register("tobakko", TablogoItem::new);
	public static final DeferredItem<Item> BURNING_CIGARETTE = REGISTRY.register("burning_cigarette", BurningCigaretteItem::new);
	public static final DeferredItem<Item> TOBACCOPLANT = doubleBlock(VilhelmlaugemodModBlocks.TOBACCOPLANT);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
