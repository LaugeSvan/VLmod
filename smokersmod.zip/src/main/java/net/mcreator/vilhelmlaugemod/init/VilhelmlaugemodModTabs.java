
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vilhelmlaugemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.vilhelmlaugemod.VilhelmlaugemodMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class VilhelmlaugemodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VilhelmlaugemodMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TOBACCO = REGISTRY.register("tobacco",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.vilhelmlaugemod.tobacco")).icon(() -> new ItemStack(VilhelmlaugemodModItems.TOBAKKO.get())).displayItems((parameters, tabData) -> {
				tabData.accept(VilhelmlaugemodModItems.CIGARETTE.get());
				tabData.accept(VilhelmlaugemodModBlocks.TOBACCOPLANT.get().asItem());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(VilhelmlaugemodModBlocks.TOBACCOPLANT.get().asItem());
		}
	}
}
