
package net.mcreator.vilhelmlaugemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TablogoItem extends Item {
	public TablogoItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
